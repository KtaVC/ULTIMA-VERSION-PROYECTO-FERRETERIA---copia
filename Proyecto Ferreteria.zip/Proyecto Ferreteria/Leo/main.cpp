#include "Interfaz.h"
#include <iostream>
using namespace std;

int main()
{
    Interfaz i;
    i.Menu_Principal();
    return 0;
}
